var Cylon = require('cylon');
var serverAddr = '140.112.30.46';
var serverPort = '1883';
var deviceID = '123'; //TODO: read from config
var topicPrefix = 'robot';

Cylon.robot({
  connections: {
    server: { adaptor: 'mqtt', host: 'mqtt://' + serverAddr + ':' + serverPort }
    ,arduino: { adaptor: 'firmata', port: '/dev/ttyS0' }
  },
 
  devices: {
    channel: { driver: 'mqtt', topic: (topicPrefix + deviceID) }
    // ,led: { driver: 'led', pin: 13 }
    ,servo: { driver: 'servo', pin: 6 }
  },
  
  work: function(my) {
    console.log("start to work!");
    my.channel.on('message', this.mqttMsgHandler);
    my.channel.publish(JSON.stringify({
      status: "connected"
    }));
    
    //servo test
    var angle = 45;
    my.servo.angle(angle);
    every((1).second(), function() {
      angle = angle + 45 ;
      if (angle > 135) {
        angle = 45
      }
      my.servo.angle(angle);
    });
  },
  
  mqttMsgHandler: function (data) {
    try {
      jsonObj = JSON.parse(data);
      console.log(jsonObj);
      if('servo' in jsonObj) {
        
      }
    }
    catch(err) {
      console.log(err);
    }
  }
  
}).start();